#include "AppClass.h"
void AppClass::InitUserVariables(void)
{
	m_pCamera->SetPosition(vector3(0.0f, 0.0f, 20.0f));

	SafeDelete(m_pGrid);
	// Create a new grid initializing its properties and compiling it
	m_pGrid = new GridClass(MEAXIS::XY);
	m_pGrid->CompileGrid();

	m_pSphere1 = new PrimitiveClass;
	m_pSphere1->GenerateSphere(1.0f, 3, MERED);

	m_pSphere2 = new PrimitiveClass;
	m_pSphere2->GenerateSphere(0.5f, 3, MEBLUE);
}

void AppClass::Update(void)
{
	// The following code works SPECIFICALLY because we're using identity matrices!!
	matrix4 m4Start = glm::translate(matrix4(IDENTITY), vector3(3.0f, 3.0f, 0.0f));
	matrix4 m4End = glm::translate(matrix4(IDENTITY), vector3(0.0f, 0.0f, 1.7f));

	vector4 v4Temp = glm::lerp(m4Start[3], m4End[3], 1.5f); // Takes the translation part of each matrix + finds a point 75% from the start to the end
															// You could also just pop the vectors in directly...

	m_m4Sphere1 = glm::translate(matrix4(IDENTITY), static_cast<vector3>(v4Temp)); // Translates according to that point

	v4Temp = glm::lerp(m4Start[3], m4End[3], 0.2f);
	m_m4Sphere2 = glm::translate(matrix4(IDENTITY), static_cast<vector3>(v4Temp));

	//First person camera movement
	if (m_bFPC == true)
		CameraRotation();
}

void AppClass::Display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear the window

	m_pGrid->Render(10.0f); //renders the grid with a 100 scale
	m_pSphere1->Render(m_m4Sphere1);
	m_pSphere2->Render(m_m4Sphere2);

	m_pGLSystem->GLSwapBuffers(); //Swaps the OpenGL buffers
}

void AppClass::Release(void)
{
	if (m_pSphere1 != nullptr)
	{
		delete[] m_pSphere1;
		m_pSphere1 = nullptr;
	}
	if (m_pSphere2 != nullptr)
	{
		delete[] m_pSphere2;
		m_pSphere2 = nullptr;
	}

	super::Release();
}