/*----------------------------------------------
Programmer: Alberto Bobadilla (labigm@gmail.com)
Date: 2015/08
----------------------------------------------*/

#include "AppClass.h"

//Define camera singleton
class CameraSingleton
{
	static CameraSingleton* instance;

private:
	matrix4 view;
	matrix4 projection;

	vector3 position;
	vector3 target;
	quaternion orientation;

public:
	static CameraSingleton* GetInstance()
	{
		if (instance == nullptr)
			instance = new CameraSingleton();
	}

	static void ReleaseInstance()
	{
		if (instance != nullptr)
			delete instance;
		instance = nullptr;
	}

	// HOW IS THIS CALCULATED
	matrix4 GetView()
	{
		glm::mat4 rotViewMat = glm::mat4_cast(orientation);
		glm::mat4 translateViewMat = matrix4(position);

		return rotViewMat * translateViewMat;
	}

	// HOW IS THIS CALCULATED ALSO???
	matrix4 GetProjection(bool bOrthographic)
	{

	}

	void SetPosition(vector3 v3Position)
	{ position = v3Position; }

	void SetTarget(vector3 v3Target)
	{ target = v3Target; }

	void SetUp(vector3 v3Up)
	{ orientation = quaternion(v3Up); }

	// z movement
	void MoveForward(float fIncrement)
	{ position = vector3(0.0f, 0.0f, fIncrement) * position; }

	// x movement
	void MoveSideways(float fIncrement)
	{ position = vector3(fIncrement, 0.0f, 0.0f) * position; }

	// y movement
	void MoveVertical(float fIncrement)
	{ position = vector3(0.0f, fIncrement, 0.0f) * position; }

	// x rotation
	void ChangePitch(float fIncrement)
	{ orientation = orientation * quaternion(vector3(fIncrement, 0.0f, 0.0f)); }

	// y rotation
	void ChangeYaw(float fIncrement)
	{ orientation = orientation * quaternion(vector3(0.0f, fIncrement, 0.0f)); }

	// z rotation
	void ChangeRoll(float fIncrement)
	{ orientation = orientation * quaternion(vector3(0.0f, 0.0f, fIncrement)); }
};

//Initializing the main program using winappi
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow)
{
	//Creating a ReEngAppClass object providing the arguments and the window handler
	AppClass Application(hInstance, lpCmdLine, nCmdShow);
	//Running the Application's Main Loop
	Application.Run();
	//Finalizing the Application
	return 0;
}